public class Car extends Automobile{

	Car(String type) {
		super(type);
		// initialize fuel.
		fuel = 30;
	}
	
	public Car() {
		
	}
	
	void setType(String type){
		super.type = type;
	}
	
	@Override
	void TurnLeft() {
		
	}
	
	@Override
	void TurnRight() {
		
	}
	
	@Override
	void IncreaseSpeed() {
		
	}
	
	@Override
	void DecreaseSpeed() {
		
	}
	
	@Override
	void Move() {
		
	}

}
